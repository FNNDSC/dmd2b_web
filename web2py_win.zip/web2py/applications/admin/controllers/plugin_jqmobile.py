response.files = response.files[:3]
response.menu = []


def index():
    return locals()


def about():
    return locals()
