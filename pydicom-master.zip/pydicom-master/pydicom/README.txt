README for pydicom distribution

pydicom is released under a modified MIT license. See the license.txt file included with the distribution, or available at https://github.com/darcymason/pydicom.

To install from a source distribution, at a command line in the source directory (where setup.py is located), type:
python setup.py install

To use the code from python, type:
import pydicom

See the examples for more details, or the online information at https://github.com/darcymason/pydicom.
