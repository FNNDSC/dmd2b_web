# dicomio.py
"""Many point of entry for pydicom read and write functions"""
from pydicom.filereader import read_file, read_dicomdir
from pydicom.filewriter import write_file

